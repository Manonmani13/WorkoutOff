package com.pro.user.registration.response;

public enum RequestOparationStatus {
 delete , success
}

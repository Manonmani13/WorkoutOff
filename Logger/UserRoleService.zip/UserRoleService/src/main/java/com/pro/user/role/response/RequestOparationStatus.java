package com.pro.user.role.response;

public enum RequestOparationStatus {
	 delete , success
}

package com.pro.user_sensitive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensitivedetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}

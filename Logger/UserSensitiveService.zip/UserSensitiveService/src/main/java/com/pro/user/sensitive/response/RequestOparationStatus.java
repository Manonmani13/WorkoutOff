package com.pro.user.sensitive.response;

public enum RequestOparationStatus {
	 delete , success
}

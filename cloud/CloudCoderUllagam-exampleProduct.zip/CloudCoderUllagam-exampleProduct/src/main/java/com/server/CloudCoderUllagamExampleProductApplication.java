package com.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudCoderUllagamExampleProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudCoderUllagamExampleProductApplication.class, args);
	}

}
